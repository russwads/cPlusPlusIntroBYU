#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include"LinkedListInterface.h"
#include<string>
#include<sstream>

using std::string;
using std::ostream;

template<typename T> class LinkedList // : public LinkedListInterface<T>
{
private:
/**
	Linked List Node
*/
	struct Node
	{
		T data;
		Node *next;

		Node(const T& data_item, Node* next_ptr = NULL) : data(data_item), next(next_ptr) {};
	};
	Node* head;

public:
/**
Constructor of LinkedList
*/
	LinkedList<T>() 
	{
		this->head = NULL;
	};
	~LinkedList<T>() { delete head; }

/**
A function that returns true if the given value is located inside of the data
@param value: the value of T that must be matched to return the function as true
*/
	bool searchMatch(T value)
	{
		Node* ptr = head;
		while (ptr != NULL)
		{
			if (ptr->data == value) { return true; }
			ptr = ptr->next;
		}
		return false;
	}

/**
Inserts beginning node into Linked List
@param value: the value that is going into the linked list
*/
	bool insertHead(T value)
	{
		if (this->head == NULL) //if there is no head, the new node will be created as the head of the list
		{
			Node* head = new Node(value,NULL); 
			return true;
		}
		else
		{
			Node* ptr = head; //first Node is head
			while (ptr != NULL) //While pointer is not NULL
			{
				if (value != ptr->data) //if the inserting value is not equal to the current pointer's data, the new node will be created at the head of the linked list.
				{
					head = new Node(value, head);
					return true;
				}
				ptr = ptr->next;
			}
		}
		return false;
	}
	//check
/**
Inserts ending node into Linked List
@param value: the value that is going into the linked list
*/
	bool insertTail(T value)
	{
		if (this->head == NULL) //if there is no head, the new node will be created as the head of the list, despite it being the tail
		{
			Node* head = new Node(value);
			return true;
		}
		else
		{
			Node* ptr = head; //first Node is head
			for (unsigned int i = 0; i < this->size(); i++)
			{
				if (value == ptr->data) { return false; }
				ptr = ptr->next;
			}
			Node* tail = new Node(value);
			ptr->next = tail;
			return true;
		}
		return false;
	}
	//check
/**
Inserts node after selected node of data
@param matchNode: node that must be in the list before the new node enters into the list
@param node: new node entering into the list
*/
	bool insertAfter(T matchNode, T node)
	{
		if (!head) { return false; } //If no head, the list has no node to match to, so the conclusion would be false
		Node* ptr = head;
		while (ptr != NULL)
		{
			if (ptr->data == matchNode) //checks to see if the matchNode is in the list
			{
				bool truth = searchMatch(node);
				if (truth == true) { return false; } //A matching node is unacceptable
				else
				{
					Node* new_node = new Node(node); //Creates new node
					new_node->next = ptr->next; //Sets new "next" pointer values
					ptr->next = new_node;
					return true;
				}
			}
			else { ptr = ptr->next; } //Increments until the end of the list so the "if" statement can check every node
		}
		return false;
	}
	//check
/**
Removes selected value from the linked list
@param value: the selected value to be removed from the list
*/
	bool remove(T value)
	{
		bool truth = searchMatch(value);
		unsigned int list_size = this->size();
		if (truth == true)
		{
			Node* ptr = head;
			unsigned int iter = 0;
			while (ptr != NULL)
			{
				if (ptr->data == value) 
				{ 
					Node* ptr2 = head;
					for (unsigned int i = 0; i < iter; i++)
					{
						ptr2 = ptr2->next;
					}
					ptr2->next = ptr2->next->next;
					delete ptr;
					return true;
				}
				ptr = ptr->next;
				iter++;
			}
		}
		else { return false; }
	}
	//check
/**
Clears linked list of all values
*/
	bool clear()
	{
		if (!head) { return false; } //returns false if there is no head or the head data is NULL
		if (!head->next) { delete head; return true; } //deletes just the head if there are no other nodes
		else
		{
			Node* ptr1 = head->next;
			for (int i = 0; i < this->size(); i++) //For the number of nodes, the pointer goes to the tail and deletes the nodes one by one
			{
				while (ptr1 != NULL)
				{
					ptr1 = ptr1->next;
				}
				delete ptr1;
				Node* ptr1 = head->next;
			}
			delete head;	 //Deleting all other nodes and pointers
			delete ptr1;
			return true;
		}
	}
	//check
/**
Returns node that resides at the desired index
@param index: the index number of the list
*/
	T at(int index)
	{
		try 
		{
			if (!head) { throw index; } //returns the fail data if there is no head or the head data is NULL
			if ((index < 0) || (index > this->size()))
			{
				throw index;
			}
			else if (index == 0) { return head->data; }
			else
			{
				Node* ptr = head;
				unsigned int iter = 1;
				while (ptr != NULL)
				{
					if (iter == index)
					{
						T value = ptr->data;
						return value;
					}
					ptr = ptr->next;
					iter++;
				}
			}
		}
		catch (int index)
		{
			cout << "";
		}
	}
	//check
/**
Returns size of the linked list
*/
	int size()
	{
//		if (!head) { return 0; }
//		else
//		{
			Node* ptr = head;
			unsigned int count = 0;
			while (ptr != NULL)
			{
				ptr = ptr->next;
				count++;
			}
			return count;
//		}
	}
	//check
/**
Returns a string of all values in the linked list
*/
	string toString() const;
	//check
/**
	Sends the toString function into the output stream
*/
	friend std::ostream& operator<< (ostream& os, const LinkedList<T>& LLfin)
	{
		os << LLfin.toString();
		return os;
	}// end operator<<
	//check
};

#endif

template<typename T>
inline string LinkedList<T>::toString() const
{
	if (!head) { return "Empty"; }
	ostringstream ss;
	Node* ptr = head;
	while (ptr != NULL)
	{
		ss << ptr->data;
		if (ptr->next != NULL) { ss << " "; }
	}
	return ss.str();
}
