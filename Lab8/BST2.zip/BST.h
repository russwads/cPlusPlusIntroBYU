#ifndef BST_H
#define BST_H

#include<string>
#include<sstream>
#include"BSTInterface.h"

using std::string;
using std::ostringstream;

template<typename T>
class BST : public BSTInterface<T>
{
private:
	struct Node
	{
	public:
		T data;
		Node* rgt;
		Node* lft;
		Node(const T& item) : data(item), rgt(nullptr), lft(nullptr) { ; }
		Node(const T& item, Node* right, Node* left) : data(item), rgt(right), lft(left) { ; }
	};
	Node* head = nullptr;

	/** Returns the node that is the in-order predecessor to the "@param node" */
	Node* inOrderPredecessor(Node* node)
	{
		Node* tempnode;
		if (node->lft == NULL) { return node; } //If there is no child to the left of the node, the function returns the beginning node
		else { tempnode = node->lft; } //"tempnode" becomes the beginning node's left node
		while (tempnode->rgt != NULL) { tempnode = tempnode->rgt; } //Traverses through this tree branch until "tempnode" reaches the right-most node
		return tempnode; //Returns the left-rightmost node, or the inOrderPredecessor
	}
	/** Recursive function buffer for addNode */
	bool insertBuff(Node*& node, const T& value)
	{
		if (node == NULL) { node = new Node(value); return true; } //Adds new node to BST 
		else if (node->data == value) { return false; } //Fail-safe if search() fails to execute correctly
		else if (value < node->data) { return insertBuff(node->lft, value); } //Recursive function begins to the left when value is less than node value
		else if (value > node->data) { return insertBuff(node->rgt, value); } //Recursive function begins to the right when value is more than node value
		else { return false; }//Syntax Error; removing complier warnings
	}
	/** Recursive function buffer for removeNode */
	bool deleteBuff(Node*& node, const T& value)
	{
		if (node == NULL) { return false; }
		else if (value < node->data) { return deleteBuff(node->lft, value); }
		else if (value > node->data) { return deleteBuff(node->rgt, value); }
		else
		{
			//One or no children
			if (node->rgt == NULL)
			{
				node = node->lft;
				return true;
			}
			else if (node->lft == NULL)
			{
				node = node->rgt;
				return true;
			}
			else
			{
				Node* iop = inOrderPredecessor(node); //Finding the IOP
				T del_data = node->data; //Switching data with node and iop
				node->data = iop->data;
				iop->data = del_data;
				return deleteBuff(node->lft, value);
			}
		}
	}
	/** Recursive function counterpart for clearTree */
	bool clear(Node*& node)
	{
		if (node->lft != NULL) { clear(node->lft); }
		if (node->rgt != NULL) { clear(node->rgt); }
		else
		{
			delete node;
			node = NULL;
			return true;
		}
	}

public:
	BST() { ; }

	/** Returns true if the value is located in the BST, else false */
	bool search(Node* tempnode, T value)
	{
		if (tempnode == NULL) { return false; } //If the node is empty, return false
		else if (tempnode->data == value) { return true; } //If the data for the node is equal to the value given, return true
		else if (value < tempnode->data) { return search(tempnode->lft, value); } //Travels to the left if the value is less than the node, and begins recursion
		else if (value > tempnode->data) { return search(tempnode->rgt, value); } //Travels to the right if the value is more than the node, and begins recursion
		else { return false; }//Syntax Error; removing complier warnings
	}

	/** Return true if node added to BST, else false */
	bool addNode(const T& value)
	{
		bool truth = search(head, value);
		if (truth == true) { return false; }
		else { return insertBuff(head, value); }
	}
	/** Return true if node removed from BST, else false */
	bool removeNode(const T& value)
	{
		bool truth = search(head, value);
		if (truth == false) { return false; }
		else { return deleteBuff(head, value); }
	}

	/** Return true if BST cleared of all nodes, else false */
	bool clearTree()
	{
		if (head == NULL) { return true; }
		else { return clear(head); }
	}
	/** Output nodes at a given level */
	bool outLevel(Node* root, int level, ostringstream& out) const
	{
		if (root == NULL) return false;
		if (level == 0)
		{
			out << " " << root->data;
			if ((root->lft != NULL) || (root->rgt != NULL)) return true;
			return false;
		}
		if ((level == 1) && !root->lft && root->rgt) out << " _";
		bool left = outLevel(root->lft, level - 1, out);
		bool right = outLevel(root->rgt, level - 1, out);
		if ((level == 1) && root->lft && !root->rgt) out << " _";
		return left || right;
	}
	/** Return a level order traversal of a BST as a string */
	string toString() const
	{
		ostringstream ss;
		if (head == NULL) 
			ss << " Empty";
		else
		{
			int level = -1;
			do
			{
				ss << endl << "  " << ++level << ":";
			} while (outLevel(head, level, ss));
		}
		return ss.str();
	}

/**	class Iterator
	{
	private:
		BST<T> hello;
		Node* root;
		size_t treesize;

	public:
		Iterator() { ; }
		Iterator(Node* groot) : root(groot) { ; }
		Iterator(BST<T> hi, Node* groot) : hello(hi), root(groot) { ; }
		Iterator(const Iterator& other) : hello(other.hello), root(other.root) { ; }
		Iterator(Iterator&& other) : hello(other.hello), root(other.root) { other.hello = nullptr; other.root = nullptr; }

		/** Return true if iterators are not equal, else false *
		bool operator!=(const Iterator& rhs) const
		{
			return !(root == *rhs);
		}

		/** Return true if iterators are equal, else false *
		bool operator==(const Iterator& rhs) const
		{
			return (root == *rhs);
		}

/**		/** Post increment iterator operator *
		Iterator operator++()
		{
			treesize++;
		}
*
		/** Dereference iterator operator *
/**		T operator*() const
		{
			return ;
		}
*		~Iterator() {;}
	}; 
	Iterator begin() 
	{ 
		Node* begin_iter = head;
		do {
			begin_iter = begin_iter->lft;
		} while (begin_iter->lft != NULL);
		Iterator buff_finish = new Iterator(begin_iter);
		Iterator iter = buff_finish;
		delete buff_finish;
		return iter;
	}
	Iterator end() 
	{ 
		Node* begin_iter = head;
		do {
			begin_iter = begin_iter->rgt;
		} while (begin_iter->rgt != NULL);
		Iterator buff_finish = new Iterator(begin_iter->rgt);
		Iterator iter = buff_finish;
		delete buff_finish;
		return iter;
	}
/**	Iterator find(T& value) 
	{ 
		
	}*/
	~BST() { clearTree(); }
};

#endif
